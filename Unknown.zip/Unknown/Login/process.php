<?php

// if($_SERVER["REQUEST_METHOD"] == "POST"){
//     $username=mysql_real_escape_string($_POST['email']);
//     $password=mysql_real_escape_string($_POST['password']);
// $bool=true;

//     mysql_connect("localhost", "root","actscdac") or die(mysql_error());//connect to server
//     mysql_select_db("testdb") or die("cannot connect to database");//connect to database
//     $query=mysql_query("select * from users"); //query the user table
//     while($row=mysql_fetch_array($query)) //display all rows from query
//     {
//             $table_users=$row['username'];
//     }
// }

$conn=new mysqli("localhost","root","","testdb");
$email=$_POST["email"];
$password=$_POST["password"];
$sql="SELECT * from users where email='".$email."'";
$result=$conn->query($sql);
if($result->num_rows > 0)
{
    while($row=$result->fetch_assoc())
    {
        if($row["password"]==$password)
        {
            echo "login succesful <br>";
            echo "welcome".$email;
        }
        else{
            echo "invalid pass<br>";
        }
    }
    
}
else{
    echo "user not found";
}
?>