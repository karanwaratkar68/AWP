<?php

$user = 'root';

$password = 'actscdac'; 

$db = 'testdb';

$db = new mysqli('localhost', $user, $password, $db) or die("Unable to connect");

if($db)
{
echo "Connection Succcess";
}
else
{
	echo "error in connection";
}

?> 