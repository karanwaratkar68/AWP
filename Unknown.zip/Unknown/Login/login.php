<html>
<head>
<title>Login Page</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frm">
<form action="process.php" method="POST">
<p>
<lable>email</lable>
<input type="text" id="email" name="email"/>
</p>
<p>
<lable>password</lable>
<input type="text" id="password" name="password"/> 
</p>
<p>

<input type="submit" id="btn" value="Login" /> 
</p>   
</form>
</body>
</html>