<html>
    <head>
        <title>Menu Driven</title>
    </head>
    <body>

        <?php
            $a=10;
            $b=20;
            echo "Shorthand operator *= <br/>";
            $a *= $b;
            echo "$a<br/>";
            echo "increment operator ++ <br/>";
            $b++; 
            echo $b." <br/>";

            echo "for looop for printing 1 to 5<br/>";
            for($i=1;$i<=5;$i++)
                echo $i." <br/>";
            
                echo "for loop for printing base 2 pow 1 to 5<br/>";
            for($i=1;$i<=5;$i++)
                echo "base 2 power $i =".pow(2,$i)." <br/>";

        ?>
    </body>
</html>