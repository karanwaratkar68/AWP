<html>
<head>
<title>
PHP Demo
</title>
</head>
<body>
<?php

$number1 = 25;
$number2 = 30;

if($number1<$number2)
{
    echo "$number2 is greater";
}
else{
    echo "$number1 is greater";

}


?>
</body>
</html>