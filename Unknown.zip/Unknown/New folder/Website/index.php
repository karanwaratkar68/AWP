<html>
    <head>
        <title>E-commerce</title>
         </head>
    <body bgcolor="#F1F3F6">
        <table border="0" width="100%" bgcolor="#2874FO"> 
            <tr>
                <td align="right"><img src="logo.png" width="100px"></td>
                <td width="200px"><input type="text" placeholder="Search.."></td>
                <th><font color="white"><a class="active" href="#">Login & SignUp</font></th>
                <th><font color="white"><a class="active" href="#">More</font></th>
                <td><img src="cart.png" width=60px><a class="active" href="#"></td>
            </tr>
        </table>
        <br/> 
        <table border="0" width="100%" bgcolor="white" height="10%">
            <tr>
                <th width="12%" bgcolor: dark-gray><select >
                <option value="Laptop">Electronics</option>
                <option value="Laptop">Laptop</option>
                <option value="Mobile">Mobile</option>
                <option value="Speaker">Speaker</option>
  </select></th>
                <th width="12%"><a class="active" href="#">TVs & Appliances</th>
                <th width="12%"><a class="active" href="#">Men</th>
                <th width="12%"><a class="active" href="#">Women</th>
                <th width="12%"><a class="active" href="#">Kids & Baby</th>
                <th width="12%"><a class="active" href="#">Home & Furniture</th>
                <th width="12%"><a class="active" href="#">Sports, Books & More</th>
            </tr>
        </table>
        <img src="banner.png" width="100%" height="50%">
        <br><br>
        <table border="0" width="100%" bgcolor="white" height="10%">
            <tr>
            <td colspan="5"><h2>Men</h2><hr></td>
            <tr>
                <th><a class="active" href="#"><img src="C1.jpg" width="75%"></th>
                <th><a class="active" href="#"><img src="C2.jpg" width="75%"></th>
                <th><a class="active" href="#"><img src="C3.jpg" width="75%"></th>
            </tr>
            <tr>
            <th align="center" >Price: 599/-</th>
            <th align="center" >Price: 699/-</th>
            <th align="center" >Price: 799/-</th>
            </tr>
        </table>
        <br>
        <table border="0" width="100%" bgcolor="white" height="10%">
            <tr>
            <td colspan="5"><h2>Electronics</h2><hr></td>
            <tr>
                <th><a class="active" href="#"><img src="laptop2.jpeg" width="75%"></th>
                <th><a class="active" href="#"><img src="laptop3.jpeg" width="75%"></th>
                <th><a class="active" href="#"><img src="laptop4.jpeg" width="75%"></th>
            </tr>
            <tr>
            <th align="center" >Price: 32999/-</th>
            <th align="center" >Price: 34599/-</th>
            <th align="center" >Price: 26899/-</th>
            </tr>
        </table>
    </body>
</html>