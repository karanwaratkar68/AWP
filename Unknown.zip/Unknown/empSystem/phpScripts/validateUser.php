<?php

// Start the session
session_start();

include 'connect.php';
$username=$_POST['username'];
$password=$_POST['password'];

$sql="select * from tblemp where email='$username' and password='$password'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    echo "Success";
 
    $cookie_name = "username";
    $cookie_value = "$username";
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
    while($rows = mysqli_fetch_array($result)) // You have to pass result into mysql_fetch_array not query string 
{
    $role= $rows["role"];
}
  
    $_SESSION["username"] = "$name";
    $_SESSION["role"] = "$role";
    echo $_SESSION["role"];
    header("Location: http://localhost/94-97/empsystem/phpScripts/welcomeUser.php"); 
} else {
    header("Location: http://localhost/94-97/empsystem/index.php");
}

?>