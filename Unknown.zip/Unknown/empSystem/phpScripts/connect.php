<?php
    $username ="root";
    $password="actscdac";
    $host="";
    $port=3306;
    // Create connection
    $conn = new mysqli($host, $username, $password,$port);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ");
}



