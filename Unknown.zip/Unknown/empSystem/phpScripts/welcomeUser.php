<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

</head>
<body>
<div class="container-fluid bg-dark text-white text-left" style="height:12vh;  font-weight: bold; font-size:24px; ">
Welcome 
<?php
if(isset($_COOKIE['username'])) {
    echo  $_COOKIE['username']."<br/>";  
}
echo $_SESSION["role"];
?>
</div>
<a class="btn btn-primary" href="../index.php" onclick="<?php session_unset();session_destroy();?>">Log Out</a>
<script src="../js/jquery-3.4.1.slim.min.js" ></script>
    <script src="../js/popper.min.js" ></script>
    <script src="../js/bootstrap.min.js" ></script>
</body>
</html>