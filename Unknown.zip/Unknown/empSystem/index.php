<?php include 'phpScripts/connect.php';?>

<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Management System </title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/login.css">
    </head>
    <body>
   <!--background-image:url('images/bg-01.jpg')-->
    <div  id="mainDiv" class="container-fluid" style="background-color:black; background-size:cover;background-position:center;">

        <div id="loginDiv">
        <span id="actLoginLabel"> Account Login</span>
        <br/>
        <form class="formcss" action="phpScripts/validateUser.php" method="post" >
        <div class="unpass">
        
        <input class="input100" type="text" name="username" placeholder="User Name"> </input>
       <span class="focus-input100" data-placeholder="&#xe82a;"></span> 
        
        </div>
        <div class="unpass" data-validate="Enter password">
		<input class="input100" type="password" name="password" placeholder="Password">
		<span class="focus-input100" data-placeholder="&#xe80f;"></span>
	    </div>

		<div id="btnDiv">
		<button class="login100-form-btn">Login</button>
		</div>
       
        </form>
        <div>
    
    </div>
    
           
    <script src="js/jquery-3.4.1.slim.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
    </body>
</html>
